package tel_ran.resume_bank.api;

public interface CompanyResponseType {
	String ALREADY_EXIST_IN_DB = "alreadyExistInDb";
	String FALSE = "false";
	String NOT_EXIST_IN_DB = "notExistInDb";
	String OK = "ok";
	String UNDER_CONSIDERATION = "/underConsideration";
	String WRONG_DATA = "wrongData";
}
