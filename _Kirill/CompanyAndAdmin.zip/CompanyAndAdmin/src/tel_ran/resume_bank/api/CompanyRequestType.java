package tel_ran.resume_bank.api;

public interface CompanyRequestType {
	String CREATE_COMPANY = "/createCompany";
	String DELITE = "/delite";
	String EDIT_PROFILE = "/editProfile";
	String GET_PROFILE = "/getProfile";
	String SEARCH_JOB_SEEKER = "/searchJobSeeker";
	String VERIFY = "/verify";
}
