package tel_ran.resume_bank.api;

public enum Verification {
VERIFIED, NOT_VERIFIED, UNDER_CONSIDERATION;
}
