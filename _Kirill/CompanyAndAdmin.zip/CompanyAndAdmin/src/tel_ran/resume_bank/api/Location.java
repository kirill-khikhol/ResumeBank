package tel_ran.resume_bank.api;

public enum Location {
	CENTER, NORTH, EAST, SOUTH;
}
