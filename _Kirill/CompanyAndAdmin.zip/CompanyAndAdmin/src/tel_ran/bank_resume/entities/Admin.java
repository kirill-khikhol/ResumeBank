package tel_ran.bank_resume.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import tel_ran.resume_bank.api.dto.AdminDTO;

@Entity
public class Admin {
	@Id
	private String login;
	private String name;
	@OneToOne(optional = false, cascade = CascadeType.ALL)
	private Contact contact;

	public Admin() {
	}

	public Admin(AdminDTO adminDTO) {
		super();
		this.login = adminDTO.getLogin();
		this.name = adminDTO.getName();
		this.contact = new Contact(login, adminDTO.getContactDTO());
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}
}
