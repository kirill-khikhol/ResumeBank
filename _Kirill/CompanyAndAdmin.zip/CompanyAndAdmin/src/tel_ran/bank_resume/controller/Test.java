package tel_ran.bank_resume.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import tel_ran.bank_resume.entities.Company;
import tel_ran.bank_resume.interfaces.ICompany;

public class Test {
	public static void main(String[] args) {
		printCompanyJSON("company1");
	}

	private static void printCompanyJSON(String companyName) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("Orm.xml");
		ICompany companyBean = (ICompany) ctx.getBean("companyModel");
		ObjectMapper om = new ObjectMapper();
		Company c = companyBean.getCompany(companyName);

		try {
			System.out.println(om.writeValueAsString(c));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
