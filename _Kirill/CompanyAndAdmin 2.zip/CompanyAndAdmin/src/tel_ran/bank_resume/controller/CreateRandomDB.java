package tel_ran.bank_resume.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import tel_ran.bank_resume.entities.Admin;
import tel_ran.bank_resume.entities.Company;
import tel_ran.bank_resume.entities.Contact;
import tel_ran.bank_resume.interfaces.IAdmin;
import tel_ran.bank_resume.interfaces.ICompany;
import tel_ran.resume_bank.api.Location;
import tel_ran.resume_bank.api.dto.AdminDTO;
import tel_ran.resume_bank.api.dto.CompanyDTO;
import tel_ran.resume_bank.api.dto.ContactDTO;

public class CreateRandomDB {
	private static final int COMPANY_AMOUNT = 100;
	private static final int ADMIN_AMOUNT = 10;
	private static final String[] COMPANY_TYPE_VALUES = { "startUP", "HR", "corporation", "unknown" };
	private static final String[] COMPANY_SIZE_VALUES = { "Small", "Medium", "Big", "Normal" };
	private static final int PERSENTAGE_OF_VARIFIED_CONPANIES = 50;

	public static void main(String[] args) {
		addRandomAdmin(ADMIN_AMOUNT);
		addRandomCompany(COMPANY_AMOUNT);
	}

	public static void addRandomAdmin(int amount) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("Orm.xml");
		IAdmin adminBean = (IAdmin) ctx.getBean("adminModel");

		String login;
		String name;
		AdminDTO adminDTO;
		for (int i = 0; i < amount; i++) {

			login = "Admin" + i;
			name = "adminName" + i;
			adminDTO = new AdminDTO(login, name, randomContactDTO(login, i));
			adminBean.addAdministrator(new Admin(adminDTO));
		}
	}

	public static ContactDTO randomContactDTO(String login, int i) {
		String[] telNum = { ("05200000" + i) };
		String[] faxNum = { ("05290000" + i) };
		String eMail = login + i + "@email.com";
		String personContact = "firstName" + i + " secondName" + i;
		ContactDTO contactDTO = new ContactDTO(telNum, faxNum, eMail, personContact);
		return contactDTO;
	}

	public static void addRandomCompany(int amount) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("Orm.xml");
		ICompany companyBean = (ICompany) ctx.getBean("companyModel");

		String login;
		String name;
		String companyType;
		String companySize;
		String[] location;
		boolean isVarified;
		boolean isDelited;
		CompanyDTO companyDTO;
		String about;

		for (int i = 0; i < amount; i++) {

			login = ("Company" + i);
			name = "CompanyName" + i;
			companyType = randomCompanyType();
			companySize = randomCompanySize();
			location = randomLocation();
			isVarified = randomVarified();
			isDelited = randomVarified();
			about = "Company " + name + " is a very good company";
			companyDTO = new CompanyDTO(login, name, companyType, companySize, location, isVarified, isDelited, about,
					randomContactDTO(login, i));
			companyBean.createCompany(new Company(companyDTO));
		}
	}

	private static String randomCompanyType() {

		String companyType = COMPANY_TYPE_VALUES[(int) (Math.random() * COMPANY_TYPE_VALUES.length)];
		return companyType;
	}

	private static String randomCompanySize() {
		String companySize = COMPANY_SIZE_VALUES[(int) (Math.random() * COMPANY_SIZE_VALUES.length)];
		return companySize;
	}

	private static String[] randomLocation() {
		List<String> location = new ArrayList<>();
		Location[] potentialLocation = Location.values();
		double r;
		for (int i = 0; i < potentialLocation.length; i++) {
			r = Math.random();
			if (r > 0.5) {
				location.add(potentialLocation[i].toString());
			}
		}

		return location.toArray(new String[location.size()]);
	}

	private static boolean randomVarified() {
		boolean result = false;
		double r = Math.random();
		if (r > (PERSENTAGE_OF_VARIFIED_CONPANIES / 100)) {
			result = true;
		}
		return result;
	}
}
