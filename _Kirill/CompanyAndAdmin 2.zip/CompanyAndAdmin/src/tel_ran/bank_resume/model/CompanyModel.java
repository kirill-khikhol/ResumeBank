package tel_ran.bank_resume.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import tel_ran.bank_resume.entities.Admin;
import tel_ran.bank_resume.entities.Company;
import tel_ran.bank_resume.entities.Contact;
import tel_ran.bank_resume.interfaces.ICompany;
import tel_ran.resume_bank.api.dto.ContactDTO;

public class CompanyModel implements ICompany {
	@PersistenceContext(unitName = "springHibernate")
	EntityManager em;

	@Override
	@Transactional
	public boolean createCompany(Company company) {
		boolean result = false;
		// check
		if (company != null && em.find(Admin.class, company.getLogin()) == null) {
			// add account
			em.persist(company);
			result = true;
		}
		return result;
	}

	@Override
	@Transactional
	public boolean removeCompany(String login) {
		boolean result = false;
		// check input data
		if (login != null) {
			Company company = em.find(Company.class, login);
			if (company != null) {
				// remove company
				em.remove(company);
				result = true;
			}
		}
		return result;
	}

	@Override
	public boolean isExist(String login) {
		boolean result = false;
		// check input data
		if (login != null) {
			if (em.find(Company.class, login) != null) {
				// remove company
				result = true;
			}
		}
		return result;
	}

	@Override
	@Transactional
	public boolean updateName(String login, String newName) {
		boolean result = false;
		// check input data
		if (login != null && newName != null) {
			Company company = em.find(Company.class, login);
			if (company != null) {
				// update name
				company.setName(newName);
				result = true;
			}
		}
		return result;
	}

	@Override
	@Transactional
	public boolean updateCompanyType(String login, String newCompanyType) {
		boolean result = false;
		// check input data
		if (login != null && newCompanyType != null) {
			Company company = em.find(Company.class, login);
			if (company != null) {
				// update company type
				company.setCompanyType(newCompanyType);
				result = true;
			}
		}
		return result;
	}

	@Override
	@Transactional
	public boolean updateCompanySize(String login, String newCompanySize) {
		boolean result = false;
		// check input data
		if (login != null && newCompanySize != null) {
			Company company = em.find(Company.class, login);
			if (company != null) {
				// update company size
				company.setComganySize(newCompanySize);
				result = true;
			}
		}
		return result;
	}

	@Override
	@Transactional
	public boolean updateLocation(String login, String[] newLocation) {
		boolean result = false;
		// check input data
		if (login != null && newLocation != null) {
			Company company = em.find(Company.class, login);
			if (company != null) {
				// update location
				company.setLocation(newLocation);
				result = true;
			}
		}
		return result;
	}

	@Override
	@Transactional
	public boolean updateIsVarified(String login, boolean newIsVarified) {
		boolean result = false;
		// check input data
		if (login != null) {
			Company company = em.find(Company.class, login);
			if (company != null) {
				// update varified status
				company.setVarified(newIsVarified);
				result = true;
			}
		}
		return result;
	}

	@Override
	@Transactional
	public boolean updateIsDelited(String login, boolean newIsDelited) {
		boolean result = false;
		// check input data
		if (login != null) {
			Company company = em.find(Company.class, login);
			if (company != null) {
				// update Delited status
				company.setVarified(newIsDelited);
				result = true;
			}
		}
		return result;
	}

	@Override
	@Transactional
	public boolean updateAbout(String login, String newAbout) {
		boolean result = false;
		// check input data
		if (login != null && newAbout != null) {
			Company company = em.find(Company.class, login);
			if (company != null) {
				// update about
				company.setAbout(newAbout);
				result = true;
			}
		}
		return result;
	}

	@Override
	@Transactional
	public boolean updateContact(String login, ContactDTO newContactDTO) {
		boolean result = false;
		if (login != null && newContactDTO != null) {
			Company company = em.find(Company.class, login);
			if (company != null) {
				company.getContact().setTelNum(newContactDTO.getTelNum()).setFaxNum(newContactDTO.getFaxNum())
						.seteMail(newContactDTO.geteMail()).setPersonContact(newContactDTO.getPersonContact());
				result = true;
			}
		}
		return result;
	}

	@Override
	public Company getCompany(String login) {
		Company result = null;
		// check input data
		if (login != null) {
			result = em.find(Company.class, login);

		}
		return result;
	}
}
