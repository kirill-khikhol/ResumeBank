package tel_ran.resume_bank.api.dto;

import java.io.Serializable;

import tel_ran.bank_resume.entities.Contact;

@SuppressWarnings("serial")
public class CompanyDTO implements Serializable {
	private String login;
	private String name;
	private String companyType;
	private String companySize;
	private String[] location;
	private boolean isVarified;
	private boolean isDelited;
	private String about;
	private ContactDTO contactDTO;

	public CompanyDTO() {}
	public CompanyDTO(String login, String name, String companyType, String companySize, String[] location,
			boolean isVarified, boolean isDelited, String about,ContactDTO contactDTO) {
		super();
		this.login = login;
		this.name = name;
		this.companyType = companyType;
		this.companySize = companySize;
		this.location = location;
		this.isVarified = isVarified;
		this.isDelited = isDelited;
		this.about = about;
		this.contactDTO = contactDTO;
	}

	public String getLogin() { return login; }

	public String getName() { return name; }

	public String getCompanyType() { return companyType; }

	public String getCompanySize() { return companySize; }

	public String[] getLocation() { return location; }

	public boolean isVarified() { return isVarified; }
	
	public boolean isDelited() { return isDelited; }

	public String getAbout() { return about; }
	
	public ContactDTO getContactDTO() { return contactDTO; }

	

}
