package tel_ran.resume_bank.api;

public interface CompanyRequestType {
	String GET_PROFILE = "/getProfile";
	String VERIFY = "/verify";
	String DELITE = "/delite";
	String EDIT_PROFILE = "/editProfile";
	String SEARCH_JOB_SEEKER = "/searchJobSeeker";
}
