package tel_ran.bank_resume.api;

public enum TypeRole {
	JOB_SEEKER,
	COMPANY,
	ADMINISTRATOR
}
