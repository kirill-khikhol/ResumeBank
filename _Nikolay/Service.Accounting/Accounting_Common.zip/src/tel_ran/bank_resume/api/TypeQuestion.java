package tel_ran.bank_resume.api;

public enum TypeQuestion {
	ON_WHAT_STREET_DID_YOU_LIVE_AS_A_CHILD,
	WHAT_IS_YOUR_GRANDMOTHERS_MAIDEN_NAME
}
