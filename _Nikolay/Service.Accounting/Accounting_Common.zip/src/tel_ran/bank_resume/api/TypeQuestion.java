package tel_ran.bank_resume.api;

public enum TypeQuestion {
	question1
}
