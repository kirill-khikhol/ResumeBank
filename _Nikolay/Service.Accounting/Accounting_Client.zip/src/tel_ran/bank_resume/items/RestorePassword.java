package tel_ran.bank_resume.items;

import tel_ran.bank_resume.api.dto.AccountDto;
import tel_ran.bank_resume.model.BankResumeWebProxy;
import tel_ran.view.InputOutput;
import tel_ran.view.menu.Item;

public class RestorePassword implements Item {
	private InputOutput io;
	private BankResumeWebProxy proxy;

	public RestorePassword(InputOutput io, BankResumeWebProxy proxy) {
		this.io = io;
		this.proxy = proxy;
	}
	
	@Override
	public String displayedName() {
		// TODO Auto-generated method stub
		return "restore password";
	}

	@Override
	public void perform() {
		AccountDto account = new AccountDto(io.getString("enter login"), null);
		System.out.println(proxy.restorePassword(account));
	}

	@Override
	public boolean isExit() {
		// TODO Auto-generated method stub
		return false;
	}

}
