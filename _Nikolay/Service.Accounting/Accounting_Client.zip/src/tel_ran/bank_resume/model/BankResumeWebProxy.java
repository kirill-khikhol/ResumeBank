package tel_ran.bank_resume.model;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.web.client.*;
import tel_ran.bank_resume.api.*;
import tel_ran.bank_resume.api.dto.*;

public class BankResumeWebProxy implements AccountRequestType, AccountResponseType {
	private static final String URL = "http://localhost:8080";
	private RestTemplate restTemplate = new RestTemplate();
	private HttpHeaders headers = new HttpHeaders();
	
	public String login(AccountDto account) {
		try {
			HttpEntity<AccountDto> requestEntity = new HttpEntity<AccountDto>(account, headers);
			return restTemplate.exchange(URL + LOGIN, HttpMethod.POST, requestEntity,
					String.class).getBody();
		} catch (RestClientException e) {
			System.out.println("ERROR: " + e.getMessage());
			return null;
		}
	}
	
	public String isExists(AccountDto account) {
		return postRequest(IS_EXISTS, account, new ParameterizedTypeReference<String>() {});
	}
	
	public String registration(FullAccountDto account) {
		return postRequest(REGISTRATION, account, new ParameterizedTypeReference<String>() {});
	}
	
	public String checkQuestion(FullAccountDto account) {
		return postRequest(CHECK_QUESTION, account, new ParameterizedTypeReference<String>() {});
	}
	
	public String reActivation(AccountDto account) {
		return postRequest(RE_ACTIVATION, account, new ParameterizedTypeReference<String>() {});
	}
	
	public String restorePassword(AccountDto account) {
		return postRequest(RESTORE_PASSWORD, account, new ParameterizedTypeReference<String>() {});
	}
	
	private <T, E> E postRequest(String nameRequest, T bodyRequest, ParameterizedTypeReference<E> responseType) {
		try {
			HttpEntity<T> requestEntity = new HttpEntity<T>(bodyRequest, headers);
			return restTemplate.exchange(URL + nameRequest, HttpMethod.POST, requestEntity,
					responseType).getBody();
		} catch (RestClientException e) {
			System.out.println("ERROR: " + e.getMessage());
			return null;
		}
	}
}
