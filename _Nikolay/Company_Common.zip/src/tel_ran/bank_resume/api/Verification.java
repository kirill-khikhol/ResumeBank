package tel_ran.bank_resume.api;

public enum Verification {
VERIFIED, NOT_VERIFIED, UNDER_CONSIDERATION;
}
