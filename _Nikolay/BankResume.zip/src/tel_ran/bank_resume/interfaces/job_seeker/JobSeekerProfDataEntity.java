package tel_ran.bank_resume.interfaces.job_seeker;

public interface JobSeekerProfDataEntity {
	public <E> void update(E entityDto);
}
