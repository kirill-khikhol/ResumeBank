package tel_ran.bank_resume.api;

public interface VerificationStatus {
	String YES = "yes";
	String NO = "no";
	String IN_PROGRESS = "inProgress";
}
