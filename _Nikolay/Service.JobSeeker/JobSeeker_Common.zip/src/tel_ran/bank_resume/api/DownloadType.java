package tel_ran.bank_resume.api;

public interface DownloadType {
	String PDF = "pdf";
	String DOC = "doc";
}
