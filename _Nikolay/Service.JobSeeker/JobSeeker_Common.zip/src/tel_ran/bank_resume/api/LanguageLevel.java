package tel_ran.bank_resume.api;

public interface LanguageLevel {
	String BASIC = "basic";
	String INDEPENDENT = "independent";
	String PROFICIENT = "proficient";
}
