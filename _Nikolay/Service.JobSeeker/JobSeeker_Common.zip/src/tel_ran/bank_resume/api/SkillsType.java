package tel_ran.bank_resume.api;

public interface SkillsType { }
