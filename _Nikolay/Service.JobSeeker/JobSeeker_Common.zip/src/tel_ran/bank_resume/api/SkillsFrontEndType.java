package tel_ran.bank_resume.api;

public interface SkillsFrontEndType extends SkillsType {
	String HTML = "html";
	String CSS = "css";
	String JAVA_SCRIPT = "javaScript";
}
