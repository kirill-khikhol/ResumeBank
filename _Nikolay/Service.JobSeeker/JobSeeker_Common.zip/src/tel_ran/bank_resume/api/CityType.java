package tel_ran.bank_resume.api;

public interface CityType {
	String REHOVOT = "rehovot";
	String TEL_AVIV = "tel-aviv";
	String HAIFA = "haifa";
}
