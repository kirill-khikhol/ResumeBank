package tel_ran.bank_resume.api;

public interface EducationDegree {
	String HIGH_SCHOOL = "highSchool";
	String COLLEGE = "college";
	String BACHELOR = "bachelor";
	String MASTER = "master";
	String PHD = "PhD";
}
