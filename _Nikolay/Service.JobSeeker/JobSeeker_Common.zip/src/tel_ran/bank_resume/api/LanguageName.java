package tel_ran.bank_resume.api;

public interface LanguageName {
	String ENGLISH = "english";
	String HEBREW = "hebrew";
	String RUSSIAN = "russian";
}
