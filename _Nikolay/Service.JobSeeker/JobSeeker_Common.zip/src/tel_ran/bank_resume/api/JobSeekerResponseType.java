package tel_ran.bank_resume.api;

public interface JobSeekerResponseType {
	String OK = "ok";
	String FALSE = "false";
	String WRONG_REQUEST = "wrongRequest";
	String EXIST = "exist";
	String NO_FOUND = "noFound";
	String REMOVED = "removed";
}
