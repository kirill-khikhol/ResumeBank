package tel_ran.bank_resume.api;

public interface JobSeekerRequestType {
	String CREATE_PROFILE = "/jobSeeker/createProfile";
	String READ_PROFILE = "/jobSeeker/readProfile";
	String UPDATE_PROFILE = "/jobSeeker/updateProfile";
	String DELETE_PROFILE = "/jobSeeker/deleteProfile";
	String RESTORE_PROFILE = "/jobSeeker/restoreProfile";
	
}
