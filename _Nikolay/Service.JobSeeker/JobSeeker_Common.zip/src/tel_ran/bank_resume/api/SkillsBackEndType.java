package tel_ran.bank_resume.api;

public interface SkillsBackEndType extends SkillsType {
	String JAVA = "java";
	String PYTHON = "python";
}
