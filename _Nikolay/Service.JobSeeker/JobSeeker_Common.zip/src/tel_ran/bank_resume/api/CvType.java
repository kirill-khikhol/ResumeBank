package tel_ran.bank_resume.api;

public interface CvType {
	String BACK_END = "backEnd";
	String FRONT_END = "frontEnd";
	String FULL_STACK = "fullStack";
	String ANDROID = "android";
	String QA = "qA";
}
