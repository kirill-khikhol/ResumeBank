package tel_ran.bank_resume.model;

import javax.persistence.*;
import javax.transaction.Transactional;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import tel_ran.bank_resume.api.JobSeekerResponseType;
import tel_ran.bank_resume.api.dto.*;
import tel_ran.bank_resume.entities.*;
import tel_ran.bank_resume.interfaces.IJobSeeker;

public class JobSeekerModel implements IJobSeeker, JobSeekerResponseType{
	@PersistenceContext(unitName="springHibernate")
	EntityManager em;
	ObjectMapper mapper = new ObjectMapper();
	
	@Override
	@Transactional
	public String createJobSeekerProfile(JobSeekerProfileDto jspDto) {
		// check profile
		String login = jspDto.getLogin();
		if (login == null) { return WRONG_REQUEST; }
		JobSeekerProfile jsp = findJobSeekerProfile(login);
		if (jsp != null) { 
			return jsp.isRemove() ? REMOVED : EXIST;
		}
		// persist person data
		PersonData personData = new PersonData(login, jspDto.getPersonData());
		em.persist(personData);
		// persist professional data
		ProfessionalDataDto profDataDto = jspDto.getProfessionalData();
		ProfessionalData profData = new ProfessionalData(login, profDataDto);
		em.persist(profData);
		// persist education
		for (EducationDto eduDto : profDataDto.getEducations()) {
			Education edu = new Education(profData, eduDto);
			em.persist(edu);
		}
		// persist language
		for (LanguageDto langDto : profDataDto.getLanguages()) {
			Language lang = new Language(profData, langDto);
			em.persist(lang);
		}
		// persist course
		for (CourseAndCertificateDto courseDto : profDataDto.getCoursesAndCertificates()) {
			CourseAndCertificate course = new CourseAndCertificate(profData, courseDto);
			em.persist(course);
		}
		// persist recomendation
		for (RecomendationDto recDto : profDataDto.getRecomendations()) {
			Recomendation rec = new Recomendation(profData, recDto);
			em.persist(rec);
		}
		// persist experience
		for (ExperienceDto expDto : profDataDto.getExperiences()) {
			Experience exp = new Experience(profData, expDto);
			em.persist(exp);
			// persist project
			for (ProjectDto projDto : expDto.getProjects()) {
				Project proj = new Project(exp, projDto);
				em.persist(proj);
			}
		}
		// persist fields visibility
		FieldsVisibility fieldsVisibility = new FieldsVisibility(login);
		em.persist(fieldsVisibility);
		// persist job seeker profile
		jsp = new JobSeekerProfile(login, jspDto.getDownloadType(),
				personData  , profData , fieldsVisibility );
		em.persist(jsp);
		return OK;
	}
	
	@Override
	public String readJobSeekerProfile(AccountDto accountDto) {
		// check profile
		JobSeekerProfile jsp = findJobSeekerProfile(accountDto.getLogin());
		if (jsp == null) { return NO_FOUND; }
		if (jsp.isRemove()) { return REMOVED; }
		// get dto
		try {
			return mapper.writeValueAsString(jsp.getJobSeekerProfileDto());
		} catch (JsonProcessingException e) {
			return FALSE;
		}
		
	}
	
	@Override
	@Transactional
	public String updateJobSeekerProfile(JobSeekerProfileDto jspDto) {
		// check profile
		JobSeekerProfile jsp = findJobSeekerProfile(jspDto.getLogin());
		if (jsp == null) { return NO_FOUND; }
		if (jsp.isRemove()) { return REMOVED; }
		// update profile and person data
		jsp.setDownloadType(jspDto.getDownloadType());
		jsp.getPersonData().update(jspDto.getPersonData());
		// update prof data
		ProfessionalData profData = jsp.getProfessionalData();
		ProfessionalDataDto profDataDto = jspDto.getProfessionalData();
		em.refresh(profData);
		updateProfDataEntity(profData.getEducations().toArray(new Education[profData.getEducations().size()]),
				profDataDto.getEducations(), profData);
		updateProfDataEntity(profData.getLanguages().toArray(new Language[profData.getLanguages().size()]),
				profDataDto.getLanguages(), profData);
		updateProfDataEntity(profData.getCousesAndSertificates().toArray(
				new CourseAndCertificate[profData.getCousesAndSertificates().size()]),
				profDataDto.getCoursesAndCertificates(), profData);
		updateProfDataEntity(profData.getRecomendations().toArray(
				new Recomendation[profData.getRecomendations().size()]),
				profDataDto.getRecomendations(), profData);
		updateProfDataEntity(profData.getExperiences().toArray(
				new Experience[profData.getExperiences().size()]),
				profDataDto.getExperiences(), profData);
		profData.update(profDataDto);
		/* update */
		
		return OK;
	}
	
	@Override
	@Transactional
	public String removeJobSeekerProfile(AccountDto accountDto, boolean remove) {
		JobSeekerProfile jsp = findJobSeekerProfile(accountDto.getLogin());
		if (jsp != null) {
			jsp.setRemove(remove);
			return OK;
		}
		return NO_FOUND;
	}
	
	private JobSeekerProfile findJobSeekerProfile(String login) {
		String jpql = "select jsp from JobSeekerProfile jsp where jsp.login = :login";
		try {
			return em.createQuery(jpql, JobSeekerProfile.class).setParameter("login", login)
					.getSingleResult();
		} catch (PersistenceException e) {
			return null;
		}
	}
	
	private <T extends JobSeekerProfDataEntity, E, D> void updateProfDataEntity(
			T[] arrEnt, E[] arrEntDto, D link) {
		if (arrEnt.length > arrEntDto.length) {
			for (int i = arrEnt.length - 1; i >= arrEntDto.length ; i--) { em.remove(arrEnt[i]); }
		}
		String entName = arrEnt.getClass().getSimpleName();
		for (int i = 0; i < arrEntDto.length; i++) {
			Experience exp = null;
			if (arrEnt.length > i) { arrEnt[i].update(arrEntDto[i]); }
			else {
				switch (entName) {
				case "Education[]": em.persist(new Education(link, arrEntDto[i])); break;
				case "Language[]": em.persist(new Language(link, arrEntDto[i])); break;
				case "CourseAndCertificate[]": em.persist(new CourseAndCertificate(link, arrEntDto[i])); break;
				case "Recomendation[]": em.persist(new Recomendation(link, arrEntDto[i])); break;
				case "Experience[]": {
					exp = new Experience(link, arrEntDto[i]);
					em.persist(exp); break;
				}
				case "Project[]": em.persist(new Project(link, arrEntDto[i])); break;
				default: break;
				}
			}
			// update projects in experience
			if (entName.equals("Experience[]")) {
				try {
					exp = (exp == null) ? (Experience) arrEnt[i] : exp;
					ExperienceDto expDto = (ExperienceDto) arrEntDto[i];
					updateProfDataEntity(exp.getProjects() == null ?
							new Project[0] : exp.getProjects().toArray(new Project[exp.getProjects().size()]),
							expDto.getProjects(), exp);
				} catch (ClassCastException e) {}
			}
		}
	}
}