package tel_ran.bank_resume.interfaces;

import tel_ran.bank_resume.api.dto.*;

public interface IJobSeeker {
	public String createJobSeekerProfile(JobSeekerProfileDto jspDto);
	public String readJobSeekerProfile(AccountDto accountDto);
	public String updateJobSeekerProfile(JobSeekerProfileDto jspDto);
	public String removeJobSeekerProfile(AccountDto accountDto, boolean remove);
}
