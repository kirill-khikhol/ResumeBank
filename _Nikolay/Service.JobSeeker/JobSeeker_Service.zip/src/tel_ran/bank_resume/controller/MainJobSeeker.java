package tel_ran.bank_resume.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@ImportResource("classpath:Orm.xml")
public class MainJobSeeker {

	public static void main(String[] args) {
		SpringApplication.run(MainJobSeeker.class, args);
	}

}
