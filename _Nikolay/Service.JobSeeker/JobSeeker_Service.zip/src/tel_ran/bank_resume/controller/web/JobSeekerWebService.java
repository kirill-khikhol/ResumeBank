package tel_ran.bank_resume.controller.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import tel_ran.bank_resume.api.*;
import tel_ran.bank_resume.api.dto.*;
import tel_ran.bank_resume.interfaces.IJobSeeker;

@RestController
public class JobSeekerWebService implements JobSeekerRequestType, JobSeekerResponseType{
	/*
	 * fields can be null ?
	 */
	@Autowired
	IJobSeeker jobSeekers;
	
	@RequestMapping(value=CREATE_PROFILE, method=RequestMethod.POST)
	public String createJobSeekerProfile(@RequestBody JobSeekerProfileDto jspDto) {
		return jobSeekers.createJobSeekerProfile(jspDto);
	}
	
	@RequestMapping(value=READ_PROFILE, method=RequestMethod.POST)
	public String readeJobSeekerProfile(@RequestBody AccountDto accountDto) {
		return jobSeekers.readJobSeekerProfile(accountDto);
	}
	
	@RequestMapping(value=UPDATE_PROFILE, method=RequestMethod.POST)
	public String updateJobSeekerProfile(@RequestBody JobSeekerProfileDto jspDto) {
		return jobSeekers.updateJobSeekerProfile(jspDto);
	}
	
	@RequestMapping(value=DELETE_PROFILE, method=RequestMethod.POST)
	public String deleteJobSeekerProfile(@RequestBody AccountDto accountDto) {
		return jobSeekers.removeJobSeekerProfile(accountDto, true);
	}
	
	@RequestMapping(value=RESTORE_PROFILE, method=RequestMethod.POST)
	public String restoreJobSeekerProfile(@RequestBody AccountDto accountDto) {
		return jobSeekers.removeJobSeekerProfile(accountDto, false);
	}
}
