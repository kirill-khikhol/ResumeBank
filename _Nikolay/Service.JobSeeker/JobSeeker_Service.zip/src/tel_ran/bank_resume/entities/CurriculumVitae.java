package tel_ran.bank_resume.entities;

import java.time.LocalDate;

import javax.persistence.*;
import tel_ran.bank_resume.api.dto.CurriculumVitaeDto;

@Entity
public class CurriculumVitae {
	@Id
	@GeneratedValue
	long cv_genVal;
	int yearsInWork;
	String[] skillsType;
	String[] companyName;
	@OneToOne
	Verification verification;
	String cvType;
	@Column(nullable = false)
	boolean enable = true;
	@Column(nullable = false)
	LocalDate dateOfEnable = LocalDate.now();
	int minSalary;
	@ManyToOne()
	JobSeekerProfile jobSeekerProfile;
	
	public CurriculumVitae() { }
	public CurriculumVitae(JobSeekerProfile jobSeekerProfile, Verification verification, CurriculumVitaeDto curriculumVitaeDto) {
		this.yearsInWork = curriculumVitaeDto.getYearsInWork();
		this.skillsType = curriculumVitaeDto.getSkillsType();
		this.companyName = curriculumVitaeDto.getCompanyName();
		this.verification = verification;
		this.cvType = curriculumVitaeDto.getCvType();
		this.minSalary = curriculumVitaeDto.getMinSalary();
		this.jobSeekerProfile = jobSeekerProfile;
	}
	
	public int getYearsInWork() { return yearsInWork; }
	public void setYearsInWork(int yearsInWork) { this.yearsInWork = yearsInWork; }
	public String[] getSkillsType() { return skillsType; }
	public void setSkillsType(String[] skillsType) { this.skillsType = skillsType; }
	public String[] getCompanyName() { return companyName; }
	public void setCompanyName(String[] companyName) { this.companyName = companyName; }
	public Verification getVerification() { return verification; }
	public void setVerification(Verification verification) { this.verification = verification; }
	public boolean isEnable() { return enable; }
	public void setEnable(boolean enable) { this.enable = enable; }
	public LocalDate getDateOfEnable() { return dateOfEnable; }
	public void setDateOfEnable(LocalDate dateOfEnable) { this.dateOfEnable = dateOfEnable; }
	public String getCvType() { return cvType; }
	public int getMinSalary() { return minSalary; }
	public void setMinSalary(int minSalary) { this.minSalary = minSalary; }
	public JobSeekerProfile getJobSeekerProfile() { return jobSeekerProfile; }
	
	public CurriculumVitaeDto getCurriculumVitaeDto() {
		return new CurriculumVitaeDto(jobSeekerProfile.getLogin(), yearsInWork, skillsType,
				companyName, verification.getVerificationDto(), cvType, dateOfEnable.toString(),
				enable, minSalary);
	}
}