package tel_ran.bank_resume.entities;

public interface JobSeekerProfDataEntity {
	public <E> void update(E entityDto);
}
