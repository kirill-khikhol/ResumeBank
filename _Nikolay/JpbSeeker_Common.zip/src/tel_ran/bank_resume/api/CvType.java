package tel_ran.bank_resume.api;

public enum CvType {
	backEnd, frontEnd, fullStack, android, qa;
}
